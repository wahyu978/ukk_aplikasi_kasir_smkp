---
"@floating-ui/react": patch
---

fix(FloatingPortal): unconditional rendering with Suspense
