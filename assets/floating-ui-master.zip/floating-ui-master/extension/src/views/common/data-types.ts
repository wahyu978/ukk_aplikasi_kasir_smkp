export type UnknownData = {type: 'Unknown'};

export type Datatype = UnknownData;
