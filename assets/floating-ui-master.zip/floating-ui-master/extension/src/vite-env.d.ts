/// <reference types="vite/client" />
/// <reference types="chrome" />
