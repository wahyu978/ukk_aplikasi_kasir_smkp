/**
 * @internal
 */
export const CONTROLLER = '__FUIDT_CONTROLLER__';

/**
 * @internal
 */
export const ELEMENT_METADATA = '__FUIDT_ELEMENT_METADATA__';

/**
 * @internal
 */
export const HTML_ELEMENT_REFERENCE = '__FUIDT_HTML_ELEMENT_REFERENCE__';

/**
 * @internal
 */
export const SERIALIZED_DATA_CHANGE = '__FUIDT_SERIALIZED_DATA_CHANGE__';