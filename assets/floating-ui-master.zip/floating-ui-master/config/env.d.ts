// This file is used to declare global types to be used on the project.
// Those global types are declared by rollup replace plugin
// on defineRollupConfig.mts

declare const __DEV__: boolean;
