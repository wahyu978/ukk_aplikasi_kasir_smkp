export default function Custom404() {
  return (
    <>
      <h1>404</h1>
      <p>Sorry, this page couldn't be found.</p>
    </>
  );
}
