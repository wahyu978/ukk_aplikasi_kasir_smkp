export function createAttribute(name: string) {
  return `data-floating-ui-${name}`;
}
