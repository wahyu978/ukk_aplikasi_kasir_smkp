# @floating-ui/react-dom

## 2.0.6

### Patch Changes

- d3a773b: fix: make `whileElementsMounted` reactive with respect from changing from a function to `undefined`

## 2.0.5

### Patch Changes

- 4c04669: chore: exports .d.mts types, solves #2472
- Updated dependencies [4c04669]
- Updated dependencies [0d18e37]
  - @floating-ui/dom@1.5.4

## 2.0.4

### Patch Changes

- 9d22d831: fix: package type import

## 2.0.3

### Patch Changes

- c1965f65: refactor: minor jsdoc/type improvements
