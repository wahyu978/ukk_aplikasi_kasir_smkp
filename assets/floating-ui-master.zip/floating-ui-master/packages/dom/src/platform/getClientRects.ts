export function getClientRects(element: Element) {
  return Array.from(element.getClientRects());
}
