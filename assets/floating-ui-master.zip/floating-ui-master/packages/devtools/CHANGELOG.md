# @floating-ui/devtools

## 0.2.2

### Patch Changes

- d824150: chore: add license field to package.json

## 0.2.1

### Patch Changes

- 180d1ad: fix: devtools controller emits event once the selected element is removed

## 0.2.0

### Minor Changes

- 3d0368e: feature: BREAKING CHANGE! introduces serialized data as an array

## 0.0.4

### Patch Changes

- 4c04669: chore: removes repeated code between devtools & extension
- 4c04669: chore: exports .d.mts types, solves #2472
- Updated dependencies [4c04669]
- Updated dependencies [0d18e37]
  - @floating-ui/dom@1.5.4
