# @floating-ui/vue

## 1.0.4

### Patch Changes

- de70c04: fix: change `isComponentPublicInstance` implementation

## 1.0.3

### Patch Changes

- 4c04669: chore: exports .d.mts types, solves #2472
- 62a5242: fix: do not throw when component type reference or floating renders nothing
- Updated dependencies [4c04669]
- Updated dependencies [0d18e37]
- Updated dependencies [afb7e5e]
  - @floating-ui/utils@0.2.0
  - @floating-ui/dom@1.5.4
