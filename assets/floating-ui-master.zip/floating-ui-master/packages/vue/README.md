# @floating-ui/vue

This is the library to use Floating UI with Vue.
