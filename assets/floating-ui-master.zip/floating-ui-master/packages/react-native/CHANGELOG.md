# @floating-ui/react-native

## 0.10.3

### Patch Changes

- 7d201f7: fix: check for virtual elements when measuring

## 0.10.2

### Patch Changes

- 4c04669: chore: exports .d.mts types, solves #2472
- Updated dependencies [4c04669]
  - @floating-ui/core@1.5.3
